module Main where

main :: IO ()
main = putStrLn "Match is just a library!"