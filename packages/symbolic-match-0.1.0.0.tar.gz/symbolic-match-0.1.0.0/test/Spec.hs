{-# LANGUAGE LambdaCase #-}
import Test.Hspec ( hspec, describe, it, shouldBe, shouldSatisfy )
import SymbolicMatch.Expr
import SymbolicMatch.Match ( matchExprsPretty, matchExprs )
import qualified SymbolicMatch.Env as E
import Data.Maybe (fromMaybe, isJust, fromJust)
import SymbolicMatch.Samples

symList :: Expr
symList = DataC "Cons" [Sym 0, DataC "Cons" [Sym 1, listNil]]


caseE :: Expr
caseE =
  Case (Sym 0)
    [Alt "Nil" [] (DataC "Error" []),
     Alt "Cons" [0, 1] (Var 0)]

depth :: Int
depth = 150

main :: IO ()
main = hspec $ do
  describe "match - basic tests" $ do

    it "match same literal" $
      matchExprsPretty depth (Lit (LitInt 45)) E.init (Lit (LitInt 45))  `shouldBe` Just []

    it "match same data constructor" $
      matchExprsPretty depth list2 E.init list2  `shouldBe` Just []

    it "match different literal" $
      matchExprsPretty depth (Lit (LitInt 60)) E.init (Lit (LitInt 59))  `shouldBe` Nothing

    it "match different data constructor" $
      matchExprsPretty depth list1 E.init list2  `shouldBe` Nothing

    it "match symbol with list" $
      matchExprsPretty depth (Sym 0) E.init list2  `shouldBe` Just [(0, [], list2)]

    it "match case" $
      matchExprsPretty depth caseE E.init (Lit (LitInt 99)) `shouldBe` Just [(0, [], DataC "Cons" [Lit (LitInt 99),WildCard])]

    it "match app with two arguments" $
      matchExprsPretty depth (App makePairF [Sym 0, Sym 1]) E.init (DataC "Pair" [Lit (LitInt 1), Lit (LitInt 2)]) `shouldBe` Just [(0, [], Lit (LitInt 1)), (1, [], Lit (LitInt 2))]

    it "match identity" $
      matchExprsPretty depth (App idF [Sym 0]) functionsEnv list1  `shouldBe` Just [(0, [], list1)]

    it "match identity in variable" $
      matchExprsPretty depth (App (Var (-3)) [Sym 0]) functionsEnv list1  `shouldBe` Just [(0, [], list1)]

    it "match pairs" $
      matchExprsPretty depth symList E.init list2 `shouldBe` Just [(0, [], Lit (LitInt 2)), (1, [], Lit (LitInt 1))]

  describe "match - first set of functions" $ do

    it "match head" $
      matchExprsPretty depth (App (Var (-2)) [Sym 0]) functionsEnv (Lit (LitInt 99)) `shouldBe` Just [(0, [], DataC "Cons" [Lit (LitInt 99),WildCard])]

    it "match length" $
      matchExprsPretty depth (App (Var (-4)) [Sym 0]) functionsEnv (DataC "S" [DataC "Z" []])  `shouldBe` Just [(0, [], DataC "Cons" [WildCard,DataC "Nil" []])]

    it "match init" $
      matchExprsPretty depth (App (Var (-1)) [Sym 0]) functionsEnv list1 `shouldBe` Just [(0, [], DataC "Cons" [Lit (LitInt 1),DataC "Cons" [WildCard, DataC "Nil" []]])]

    it "match init (can't match)" $
      matchExprsPretty depth (App (Var (-1)) [list2]) functionsEnv list1 `shouldBe` Nothing

    it "match append (first is symbol)" $
      matchExprsPretty depth (App (Var (-5)) [Sym 0, list2]) functionsEnv list3  `shouldBe` Just [(0, [], DataC "Cons" [Lit (LitInt 3),DataC "Nil" []])]

    it "match append (second is symbol)" $
      matchExprsPretty depth (App (Var (-5)) [listToCons [Lit $ LitInt 3], Sym 0]) functionsEnv list3  `shouldBe` Just [(0, [], listToCons $ map (Lit . LitInt) [2, 1])]

    it "match append (both symbols)" $
      matchExprsPretty depth (App (Var (-5)) [Sym 0, Sym 1]) functionsEnv list3
        `shouldSatisfy` (\case
       Nothing -> False
       Just cs -> case head cs of
         (0, [], l1) -> case cs !! 1 of
           (1, [], l2) -> consToList l1 ++ consToList l2 == consToList list3
           _ -> False
         _ -> False)

    it "match reverse iterative" $
      matchExprsPretty depth (App (Var (-7)) [Sym 0, listNil]) functionsEnv list2  `shouldBe` Just [(0, [], DataC "Cons" [Lit (LitInt 1),DataC "Cons" [Lit (LitInt 2),DataC "Nil" []]])]

    it "match reverse" $
      matchExprsPretty depth (App (Var (-6)) [Sym 0]) functionsEnv list3  `shouldBe` Just [(0, [], DataC "Cons" [Lit (LitInt 1),DataC "Cons" [Lit (LitInt 2),DataC "Cons" [Lit (LitInt 3),DataC "Nil" []]]])]

    it "match reverse (can't match)" $
      matchExprsPretty depth (App (Var (-6)) [list3]) functionsEnv list3  `shouldBe` Nothing

    it "match map (no symbols)" $
      matchExprsPretty depth (App (Var (-8)) [Var (-13), hsToCi [0, 1, 2]]) functionsEnv (listToCons [false, true, false]) `shouldBe` Just []
    
    it "match map (no symbols, can't match)" $
      matchExprsPretty depth (App (Var (-8)) [Var (-13), hsToCi [0, 1, 2]]) functionsEnv (listToCons [false, true, true]) `shouldBe` Nothing

    it "match map (fn symbol, can't match)" $
      matchExprsPretty depth (App (Var (-8)) [Sym 0, hsToCi [0, 1, 2]]) functionsEnv (listToCons [false, true]) `shouldBe` Nothing

    it "match map (fn is the symbol)" $
      matchExprsPretty depth (App (Var (-8)) [Sym 0, listToCons (map (Lit . LitInt) [0, 1, 2])]) functionsEnv list3  `shouldBe` Just [(0, [Lit (LitInt 0)], Lit (LitInt 3)), (0, [Lit (LitInt 1)], Lit (LitInt 2)), (0, [Lit (LitInt 2)], Lit (LitInt 1))]

    it "match map (both symbols)" $
      matchExprsPretty depth (App (Var (-8)) [Sym 0, Sym 1]) functionsEnv list3  `shouldBe` Just [(0, [Sym 1000], Lit (LitInt 3)), (0, [Sym 1002], Lit (LitInt 2)), (0, [Sym 1004], Lit (LitInt 1)), (1, [], DataC "Cons" [Sym 1000,DataC "Cons" [Sym 1002,DataC "Cons" [Sym 1004,DataC "Nil" []]]])]

    it "match filter (can't match)" $
      matchExprsPretty depth (App (Var (-9)) [Sym 0, listToCons (map (Lit . LitInt) [0, 1, 2])]) functionsEnv list3  `shouldBe` Nothing

    it "match filter (can't match 2)" $
      matchExprsPretty depth (App (Var (-9)) [Var (-13), hsToCi [1, 2, 3]]) functionsEnv (hsToCi [1, 2, 3])  `shouldBe` Nothing

    it "match filter (can't match 3: contradition)" $
      matchExprsPretty depth (App (Var (-9)) [Sym 0, hsToCi [1, 1]]) functionsEnv (hsToCi [1])  `shouldBe` Nothing

    it "match filter (can't match 4: contradition)" $
      matchExprsPretty depth (App (Var (-9)) [Sym 0, hsToCi [1, 2, 3]]) functionsEnv (hsToCi [4])  `shouldBe` Nothing

    it "match filter (fn is the symbol)" $
      matchExprsPretty depth (App (Var (-9)) [Sym 0, list3]) functionsEnv list1  `shouldBe` Just [(0, [Lit (LitInt 1)], DataC "True" []), (0, [Lit (LitInt 2)], DataC "False" []), (0, [Lit (LitInt 3)], DataC "False" [])]

    it "match filter (list is the symbol)" $
      matchExprsPretty depth (App (Var (-9)) [Var (-13), Sym 0]) functionsEnv (hsToCi [1, 3]) 
        `shouldSatisfy` (\case
       Nothing -> False
       Just cs -> length cs == 1 && (case head cs of
         (0, [], l) -> filter odd (ciToHs l) == [1, 3]
         _ -> False)
      ) 

    it "match filter (both symbols)" $
      matchExprsPretty depth (App (Var (-9)) [Sym 0, Sym 1]) functionsEnv list3  `shouldBe` Just [(0, [Sym 1000], DataC "True" []), (0, [Sym 1002], DataC "True" []), (0, [Sym 1004], DataC "True" []), (1, [], DataC "Cons" [Lit (LitInt 3),DataC "Cons" [Lit (LitInt 2),DataC "Cons" [Lit (LitInt 1),DataC "Nil" []]]])]

    it "match take (num is the symbol)" $
      matchExprsPretty depth (App (Var (-10)) [Sym 0, list3]) functionsEnv (listToCons [Lit $ LitInt 3, Lit $ LitInt 2])  `shouldBe` Just [(0, [], DataC "S" [DataC "S" [DataC "Z" []]])]

    it "match take (list is the symbol)" $
      matchExprsPretty depth (App (Var (-10)) [intToNat 2, Sym 0]) functionsEnv (listToCons [Lit $ LitInt 3, Lit $ LitInt 2])  `shouldBe` Just [(0, [], DataC "Cons" [Lit (LitInt 3),DataC "Cons" [Lit (LitInt 2),WildCard]])]

    it "match take (both symbols)" $
      matchExprsPretty depth (App (Var (-10)) [Sym 1, Sym 0]) functionsEnv (listToCons [Lit $ LitInt 3, Lit $ LitInt 2])
        `shouldSatisfy` (\case
       Nothing -> False
       Just cs -> length cs == 2 && (
         case head cs of
           (0, [], list) ->
             case cs !! 1 of
               (1, [], num) -> take (natToInt num) (consToList list) == [Lit $ LitInt 3, Lit $ LitInt 2]
               _ -> False
           _->False))

    it "match fold add (def is the symbol)" $
      matchExprsPretty depth (App (Var (-12)) [Var (-11), Sym 0, listToCons [intToNat 2, intToNat 1]]) functionsEnv (s (s (s (s z)))) `shouldBe` Just [(0, [], DataC "S" [DataC "Z" []])]

    it "match fold add (list is the symbol)" $
      matchExprsPretty depth (App (Var (-12)) [Var (-11), s z, Sym 0]) functionsEnv (s (s (s (s z))))
        `shouldSatisfy` (\case
       Nothing -> False
       Just cs -> length cs == 1 && (case head cs of (0, [], list) -> sum (ciToHs list) == 3; _ -> False))

    it "match fold add (fn is the symbol)" $
      matchExprsPretty depth (App (Var (-12)) [Sym 0, s z, listToCons [intToNat 2, intToNat 1]]) functionsEnv (s (s (s (s z))))
        `shouldSatisfy` (\case
       Nothing -> False
       Just cs -> length cs == 1 && (case head cs of (0, args, val) -> natToInt val == 4; _ -> False))

    it "match fold add (all symbols)" $
      matchExprsPretty depth (App (Var (-12)) [Sym 0, Sym 1, Sym 2]) functionsEnv (s (s z)) `shouldBe` Just [(1, [], DataC "S" [DataC "S" [DataC "Z" []]]), (2, [], DataC "Nil" [])]

    it "match zip (all symbols)" $
      matchExprsPretty depth (App (Var (-14)) [Sym 0, Sym 1]) functionsEnv (listToCons [pair z (s z), pair (s z) z]) 
        `shouldSatisfy` (\case
       Nothing -> False
       Just cs -> length cs == 2 && (
         case head cs of
           (0, [], a) -> case cs !! 1 of
             (1, [], b) -> 
               let a0 = getConsIndex a 0
                   a1 = getConsIndex a 1
                   b0 = getConsIndex b 0
                   b1 = getConsIndex b 1 in
                    all isJust [a0, a1, b0, b1] &&
                    fromJust a0 == z &&
                    fromJust a1 == s z &&
                    fromJust b0 == s z &&
                    fromJust b1 == z
             _ -> False
           _ -> False)
      )

    it "match replicate (all symbols)" $
      matchExprsPretty depth (App (Var (-15)) [Sym 0, Sym 1]) functionsEnv (listToCons [z, z, z, z, z]) `shouldBe` Just [(0, [], DataC "S" [DataC "S" [DataC "S" [DataC "S" [DataC "S" [DataC "Z" []]]]]]), (1, [], DataC "Z" [])]

    it "match replicate (can't match)" $
      matchExprsPretty depth (App (Var (-15)) [Sym 0, Sym 1]) functionsEnv (listToCons [z, s z, z, z, z]) `shouldBe` Nothing

    it "match fromMaybe (both symbols)" $
      matchExprsPretty depth (App (Var (-16)) [Sym 0, Sym 1]) functionsEnv z 
        `shouldSatisfy` (\case
       Nothing -> False
       Just cs -> length cs >= 1 && length cs <= 2 && (case head cs of
         (0, [], a) -> case cs !! 1 of
           (1, [], b) -> b == DataC "Nothing" [] && a == z
           _ -> False
         (1, [], b) -> b == DataC "Just" [z]
         _ -> False) 
      ) 

    it "match fromMaybe (def is the symbol)" $
      matchExprsPretty depth (App (Var (-16)) [Sym 0, DataC "Just" [z]]) functionsEnv z `shouldBe` Just []

    it "match fromMaybe (can't match)" $
      matchExprsPretty depth (App (Var (-16)) [Sym 0, DataC "Just" [z]]) functionsEnv (s z) `shouldBe` Nothing

    it "match partitionEithers" $
      matchExprsPretty depth (App (Var (-33)) [Sym 0]) functionsEnv (pair listNil listNil) `shouldBe` Just [(0, [], listNil)]

-- TODO
    {-it "match partitionEithers 2" $
      matchExprsPretty (App (Var (-33)) 
        [listToCons [left (intToNat 3), right (intToNat 4)]]) 
        functionsEnv 
        (pair (cons (intToNat 3) listNil) (cons (intToNat 4) listNil)) 
      `shouldBe` Just []
    -}