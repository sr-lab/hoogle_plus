# symbolic-match
Artifact developed  by Henrique Guerra in his MSc Thesis, 2022, at IST, Lisbon.